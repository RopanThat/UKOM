
<!-- Awal Footer -->
     <div class="row bg-primary text-light m-0">
        <div class="col-12">
            <div class="container">
                
                <hr>
                <div class="row">
                    <div class="col-8">
                        <p class="fs-5">&copy; Copyright Wimcycle. 2025</p>
                    </div>
                    <div class="col-4 text-end">
                        <a href="http://instagram.com" class="text-light text-decoration-none" target="blank">
                            <i class="bi bi-instagram fs-5 mx-1"></i> wimcycleid
                        </a>
                        <a href="http://facebook.com" class="text-light text-decoration-none" target="blank">
                            <i class="bi bi-facebook fs-5 mx-1"></i> Wimcycle Indonesia
                        </a>
                    </div>
                </div>

            </div>
        </div>
     </div>
    <!-- Akhir Footer -->
    
    <script src="<?= base_url."bootstrap/js/bootstrap.bundle.js"; ?>"></script>

    <!-- <script>
        window.addEventListener('pageshow', function(event) {
            if (event.persisted || 
            performance.getEntriesByType("navigation")[0].type === "back_forward") {
                location.reload(true);
            }
        });
    </script> -->

</body>
</html>